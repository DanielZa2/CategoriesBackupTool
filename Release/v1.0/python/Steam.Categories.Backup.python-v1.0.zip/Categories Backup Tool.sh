#!/bin/bash
pythonw GUI.py